#ifndef __SAIC_CAMERASERVICE__H__
#define __SAIC_CAMERASERVICE__H__

#include <camera/camera_api.h>
#include <thread>
#include <atomic>


const uint8_t CameraNumber = 4; //camera number that are used
const uint32_t CameraUserBufferLength = 20; // user 
const uint32_t CameraHight = 1080;
const uint32_t CameraWidth = 1280;
const uint32_t CameraFrameSize = CameraWidth*CameraHight*2; // Size of encoded frame
/**
 * Threads can have a scheduling priority ranging from 1 to 255 (the highest priority), independent of the scheduling policy. 
 * A thread inherits the priority of its parent thread by default.
 * Unprivileged threads can have a priority ranging from 1 to 63 (by default)
 * priority is 10 by default.
 */
const int32_t CameraThreadPriority = 63;

/**
 * @brief store raw frame information
 * @note pInBuf: a array pointer, the length should be consistent with CameraNumber.
 */
struct FrameData{
  uint8_t camNum = CameraNumber;
  uint32_t frameCount = 0;
  int64_t timeStamp = 0;
  camera_buffer_t* pInBuf = NULL;
};
/**
 * @brief CameraService captures and dispatchs synchronized images to application using QNX camera event mode.
 * @note Only transfer camera buffer pointer, so it is zero-copy. 
 *       And JUST be care about the validity of the captured frame, use tham as soon as possible after 
 * @Usage:
 * 
**/
class CameraService{
//Camera service status 
enum CameraStatus_t{
  CAMERA_UNINIT = 0,
  CAMERA_INITED = 1,
  CAMERA_STARTED = 2,
  CAMERA_CLOSED = 4
};
public:
  CameraService();
  ~CameraService();
/**
 * @brief Initial and configure cameras.
 * @property 
 *      IMAGE_HEIGHT: 960
 *      IMAGE_WIDTH:  1280
 *      IMAGE_FRAMERATE: 25 FPS
 *      IMAGE_FORMAT: YUV422
 *      IMAGE_NUMUSERBUFFERS: 21 //Frame keep about 840ms. camera owner buffer
 * @note camera frame rate only support 25 fps using QNX API(WHY? )
 * TODO: Software simulation to modify frame rate. 
 */
  int16_t init(double frameRate=25);
/**
 * @brief cameras start capture image and push into circle buffer.
 * @note Schedpolicy of camera thread is Round-robin by default.
 */
  int16_t start();
/**
 * @brief Close all cameras.
 */
  int16_t close();
/**
 * @brief Get lastest frame data.
 * @note The frame data JUST transfer pointer of camera buffer. SO to avoid data that is overwritten,
 *        the data should be used as soon as possible.
 * Theoretically, the VAILD time of data is CameraUserBufferLength*1000/mFrameRate.
 */
  int16_t getLastestFrame(FrameData& frameData);

private:
/**
 * @brief Event capture thread in Camera API event mode.
 * The thread captures and synchronizes all channel camera event then put raw frame into buffer.
 * mPostCopy specifies how to push raw frame into buffer. True represents push by deep copy, and False represents 
 *            push camera's buffer pointer into CameraService's buffer.
 * The thread can be terminated when mCSThreadTerminate is set true.
 */
  void multiViewfinderEventThread();
/**
 * @brief Clean camera driver.
 * Called when cameras error or close.
 */
  int16_t cleanupCamera();
  
private:
//camera service variable
  const uint32_t mCamThreadPrio;
  const uint8_t mCamNum;
  uint32_t mPutUsrBufCnt;
  camera_handle_t mCameraHandle[CameraNumber];
  int32_t mErrFlags[CameraNumber];
  int32_t mCamServiceStatus;
  double mFrameRate = 25.0;
  std::thread mCameraServiceThread;
  std::atomic<bool> mCSThreadTerminate;  

//buffer variable
  //Store camera Inbuf data when postCopy is false.
  camera_buffer_t mCamInbufS[CameraUserBufferLength][CameraNumber];
  const uint32_t mUsrBufLen;
  std::atomic<uint8_t> mLastestFrameIndex;
  FrameData mFrameUsrBufDataS[CameraUserBufferLength];
};




#endif
