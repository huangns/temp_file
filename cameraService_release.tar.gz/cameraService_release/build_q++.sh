#!/bin/bash

source /home/xiaoxiangcao/qnx_iecu/qnxsdp-env.sh
#export CC=/home/nvidia-qnx/qos20_iecu/host/linux/x86_64/usr/bin/qcc
#export CXX=/home/nvidia-qnx/qos20_iecu/host/linux/x86_64/usr/bin/q++

cd ./build
cmake -DCMAKE_SYSTEM_VERSION="700" -DCMAKE_SYSTEM_PROCESSOR="aarch64" -DCMAKE_TOOLCHAIN_FILE=./toolchain_qnx.cmake -G"Unix Makefiles" ..

make -j4

