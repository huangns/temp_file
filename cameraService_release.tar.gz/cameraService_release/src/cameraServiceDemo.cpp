
#include <iostream>
#include <vector>
#include "cameraService.h"
#include "opencv2/opencv.hpp"
#include <chrono> 



const uint32_t SaveNum = 5;
int main()
{
	CameraService cameraService;
	cameraService.init();
	cameraService.start();
	FrameData frameData;
	std::vector<cv::Mat> bgrImgs;
	for(int i=0; i<CameraNumber; ++i){
		bgrImgs.emplace_back(CameraHight, CameraWidth, CV_8UC3, cv::Scalar(0,0,0));
	}
	int64_t lastFrameCount = 0;
	uint32_t imgCount = 0;
  	cv::Mat imgYUV(CameraHight, CameraWidth, CV_8UC2);
  	auto t_last = std::chrono::high_resolution_clock::now();
	while(true){
		cameraService.getLastestFrame(frameData);

		if(frameData.frameCount == lastFrameCount){
      	std::cout<< "Sleep 1ms"<<std::endl;
			usleep(1000);
		}else{
			std::cout<< "Save img ID: "<< ++imgCount << "framestamp:";
			for(int i=0; i<CameraNumber; ++i){
        imgYUV.data = frameData.pInBuf[i].framebuf;
				cv::cvtColor(imgYUV, bgrImgs[i], CV_YUV2BGR_UYVY);
        std::cout<<' '<<frameData.pInBuf[i].frametimestamp;
			}
      std::cout<<std::endl;

      auto t_new = std::chrono::high_resolution_clock::now();
      std::cout<<"Loop time: "<<std::chrono::duration<double, std::milli>(t_new - t_last).count()<<"ms"<<std::endl;
      t_last = t_new;
			//save images
			for(int i=0; i<CameraNumber; ++i){
				std::stringstream ss;
				ss<<"test_" << i <<'_'<< imgCount <<".jpg\0";
				cv::imwrite(ss.str(), bgrImgs[i]);
			}
			lastFrameCount = frameData.frameCount;
			if(imgCount == SaveNum)
				break;
		}
		
	}
	cameraService.close();
	return 0;
}
