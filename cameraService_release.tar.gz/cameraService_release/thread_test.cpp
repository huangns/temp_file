//
// Created by hns on 20-1-20.
//
#include<unistd.h>
#include <thread>
#include <iostream>

void thread1()
{
    while(true)
    {
        std::cout<<"thread 1 test"<<std::endl;
        usleep(100000);
    }
}
void thread2()
{
    while(true)
    {
        std::cout<<"thread 2 test"<<std::endl;
        usleep(100000);
    }
}
int main()
{
    std::cout<<"thread test"<<std::endl;
    std::thread thread_obj_1(thread1);
    std::thread thread_obj_2(thread2);

    thread_obj_1.join();
    thread_obj_2.join();
    return 0;
}